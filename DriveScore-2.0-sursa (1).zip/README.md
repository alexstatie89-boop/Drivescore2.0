# DriveScore 2.0

Cardul cu câștig NET / km peste Bolt Driver.

## Cum obții APK-ul
**GitHub (fără Android Studio):** creezi un repo, urci tot conținutul acestui folder (inclusiv `.github`),
apoi la *Actions → Build APK → Run workflow*. După ~3 min descarci `DriveScore-apk` → `app-debug.apk`.

**Android Studio:** *File → Open* pe folder, apoi *Build → Build APK(s)*.

## Instalare
1. Prima dată dezinstalează vechiul DriveScore (e semnat cu altă cheie). Următoarele versiuni se instalează peste.
2. Deschide aplicația → apasă bannerul de sus → Accesibilitate → activează DriveScore.
   (Android 13+: Setări → Aplicații → DriveScore → ⋮ → „Permite setări restricționate”, apoi activezi.)
3. Din tabul Setări pui comisionul, consumul, prețul combustibilului etc. Simulatorul arată cardul live.
