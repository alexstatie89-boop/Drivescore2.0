package ro.drivescore

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {

    private lateinit var content: LinearLayout
    private lateinit var statusView: TextView
    private lateinit var tabHistory: TextView
    private lateinit var tabSettings: TextView
    private var tab = 0
    private var simRefresh: (() -> Unit)? = null

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    // ---------- helpers UI ----------
    private fun tv(text: String, size: Float, color: Int = Ui.TEXT, bold: Boolean = false): TextView {
        val t = TextView(this)
        t.text = text
        t.textSize = size
        t.setTextColor(color)
        if (bold) t.typeface = Typeface.DEFAULT_BOLD
        return t
    }

    private fun card(): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.background = Ui.rounded(Ui.SURFACE, dp(18).toFloat())
        c.setPadding(dp(16), dp(14), dp(16), dp(14))
        val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        lp.bottomMargin = dp(12)
        c.layoutParams = lp
        return c
    }

    private fun serviceEnabled(): Boolean {
        val s = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        return s.contains("ro.drivescore") && s.contains("OfferService")
    }

    // ---------- ciclu de viață ----------
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Ui.BG
        window.navigationBarColor = Ui.BG

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Ui.BG)

        // antet
        val header = LinearLayout(this)
        header.orientation = LinearLayout.VERTICAL
        header.setPadding(dp(20), dp(18), dp(20), dp(8))
        header.addView(tv("DriveScore", 26f, Ui.TEXT, true))
        statusView = tv("", 13f, Ui.MUTED)
        statusView.setPadding(0, dp(4), 0, 0)
        statusView.setOnClickListener {
            if (!serviceEnabled()) startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        header.addView(statusView)
        root.addView(header)

        // taburi
        val tabs = LinearLayout(this)
        tabs.orientation = LinearLayout.HORIZONTAL
        tabs.setPadding(dp(16), dp(4), dp(16), dp(8))
        tabHistory = tabView("Istoric") { tab = 0; render() }
        tabSettings = tabView("Setări") { tab = 1; render() }
        tabs.addView(tabHistory, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        tabs.addView(tabSettings, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(tabs)

        content = LinearLayout(this)
        content.orientation = LinearLayout.VERTICAL
        content.setPadding(dp(16), dp(4), dp(16), dp(24))
        val scroll = ScrollView(this)
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))

        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        updateStatus()
        render()
    }

    private fun tabView(label: String, onClick: () -> Unit): TextView {
        val t = tv(label, 15f, Ui.TEXT, true)
        t.gravity = Gravity.CENTER
        t.setPadding(0, dp(10), 0, dp(10))
        t.setOnClickListener { onClick() }
        val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        lp.setMargins(dp(4), 0, dp(4), 0)
        t.layoutParams = lp
        return t
    }

    private fun updateStatus() {
        if (serviceEnabled()) {
            statusView.text = "●  Activ — cardul apare automat în Bolt Driver"
            statusView.setTextColor(Ui.GREEN)
        } else {
            statusView.text = "●  Dezactivat — apasă aici și activează „DriveScore” la Accesibilitate"
            statusView.setTextColor(Ui.AMBER)
        }
    }

    private fun render() {
        simRefresh = null
        tabHistory.background = Ui.rounded(if (tab == 0) Ui.SURFACE2 else Ui.BG, dp(14).toFloat())
        tabSettings.background = Ui.rounded(if (tab == 1) Ui.SURFACE2 else Ui.BG, dp(14).toFloat())
        tabHistory.setTextColor(if (tab == 0) Ui.TEXT else Ui.MUTED)
        tabSettings.setTextColor(if (tab == 1) Ui.TEXT else Ui.MUTED)
        content.removeAllViews()
        if (tab == 0) renderHistory() else renderSettings()
    }

    // ---------- ISTORIC ----------
    private fun renderHistory() {
        val rides = Store.history(this)
        val cal = Calendar.getInstance()
        cal.set(Calendar.HOUR_OF_DAY, 0)
        cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        val dayStart = cal.timeInMillis
        val today = rides.filter { it.ts >= dayStart }

        content.addView(summaryCard("AZI", today))
        content.addView(summaryCard("TOTAL", rides))

        if (rides.isEmpty()) {
            val c = card()
            c.addView(tv("Nicio cursă salvată încă.", 15f, Ui.TEXT, true))
            val hint = tv(
                "Când apeși „Acceptă” în Bolt, cursa apare aici și cardul dispare. " +
                    "Dacă nu se salvează singură, ține apăsat pe card ca s-o salvezi manual.",
                13f, Ui.MUTED
            )
            hint.setPadding(0, dp(6), 0, 0)
            c.addView(hint)
            content.addView(c)
            return
        }

        val fmt = SimpleDateFormat("dd.MM  HH:mm", Locale.forLanguageTag("ro-RO"))
        for (r in rides.take(200)) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.background = Ui.rounded(Ui.SURFACE, dp(16).toFloat())
            row.setPadding(dp(14), dp(12), dp(14), dp(12))
            val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            lp.bottomMargin = dp(8)
            row.layoutParams = lp

            val dot = View(this)
            dot.background = Ui.rounded(Ui.levelColor(r.level), dp(8).toFloat())
            row.addView(dot, LinearLayout.LayoutParams(dp(14), dp(14)))

            val col = LinearLayout(this)
            col.orientation = LinearLayout.VERTICAL
            col.setPadding(dp(12), 0, 0, 0)
            col.addView(tv(Fmt.d2(r.netPerKm) + " lei/km net  ·  " + Fmt.d1(r.totalKm) + " km", 16f, Ui.TEXT, true))
            col.addView(
                tv(
                    fmt.format(Date(r.ts)) + "  ·  net " + Fmt.d2(r.net) + " lei din " + Fmt.d2(r.price) +
                        "  ·  " + Fmt.d1(r.pickupKm) + " + " + Fmt.d1(r.tripKm) + " km",
                    12f, Ui.MUTED
                )
            )
            row.addView(col, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))

            row.setOnLongClickListener {
                AlertDialog.Builder(this)
                    .setTitle("Ștergi cursa?")
                    .setPositiveButton("Șterge") { _, _ ->
                        Store.deleteRide(this, r.ts)
                        render()
                    }
                    .setNegativeButton("Anulează", null)
                    .show()
                true
            }
            content.addView(row)
        }

        val clear = tv("Șterge tot istoricul", 14f, Ui.RED, true)
        clear.gravity = Gravity.CENTER
        clear.setPadding(0, dp(16), 0, dp(8))
        clear.setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("Ștergi tot istoricul?")
                .setPositiveButton("Șterge") { _, _ ->
                    Store.clearHistory(this)
                    render()
                }
                .setNegativeButton("Anulează", null)
                .show()
        }
        content.addView(clear)
    }

    private fun summaryCard(title: String, rides: List<Ride>): LinearLayout {
        val c = card()
        c.addView(tv(title, 12f, Ui.MUTED, true))
        val net = rides.sumOf { it.net }
        val km = rides.sumOf { it.totalKm }
        val avg = if (km > 0) net / km else 0.0

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.setPadding(0, dp(6), 0, 0)
        row.addView(stat("CURSE", rides.size.toString()), LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(stat("NET", Fmt.d1(net) + " lei"), LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.3f))
        row.addView(stat("KM", Fmt.d1(km)), LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(stat("NET/KM", Fmt.d2(avg)), LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        c.addView(row)
        return c
    }

    private fun stat(label: String, value: String): LinearLayout {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.addView(tv(label, 10f, Ui.MUTED))
        col.addView(tv(value, 18f, Ui.TEXT, true))
        return col
    }

    // ---------- SETĂRI ----------
    private fun renderSettings() {
        // simulator
        val sim = card()
        sim.addView(tv("SIMULATOR", 12f, Ui.MUTED, true))
        val simHint = tv("Încearcă o cursă și vezi exact cum arată cardul cu setările tale.", 13f, Ui.MUTED)
        simHint.setPadding(0, dp(4), 0, dp(8))
        sim.addView(simHint)

        val oc = OverlayCard(this)
        val holder = LinearLayout(this)
        holder.orientation = LinearLayout.VERTICAL
        holder.addView(oc.view, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))

        var simPrice = "28"
        var simPick = "2"
        var simTrip = "7"
        val refresh: () -> Unit = {
            val p = simPrice.replace(',', '.').toDoubleOrNull() ?: 0.0
            val a = simPick.replace(',', '.').toDoubleOrNull() ?: 0.0
            val b = simTrip.replace(',', '.').toDoubleOrNull() ?: 0.0
            if (p > 0.0 && a + b > 0.0) {
                val o = Offer(p, a, b, 0, 0, true)
                oc.bind(o, Scorer.score(o, Store.config(this)))
                oc.view.visibility = View.VISIBLE
            } else {
                oc.view.visibility = View.INVISIBLE
            }
        }
        simRefresh = refresh

        sim.addView(numberRow("Preț brut (lei)", simPrice) { simPrice = it; refresh() })
        sim.addView(numberRow("Km până la pasager", simPick) { simPick = it; refresh() })
        sim.addView(numberRow("Km cu pasagerul", simTrip) { simTrip = it; refresh() })
        val lpH = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        lpH.topMargin = dp(10)
        sim.addView(holder, lpH)
        content.addView(sim)
        refresh()

        // costuri
        val costs = card()
        costs.addView(tv("COSTURI (pentru „net”)", 12f, Ui.MUTED, true))
        costs.addView(settingRow("comm", "Comision platformă (%)", 20.0))
        costs.addView(settingRow("cons", "Consum (l sau kWh / 100 km)", 7.0))
        costs.addView(settingRow("eprice", "Preț combustibil / energie (lei)", 7.5))
        costs.addView(settingRow("maint", "Mentenanță + uzură (lei/km)", 0.20))
        costs.addView(settingRow("fix", "Costuri fixe lunare: asigurare, taxe (lei)", 0.0))
        costs.addView(settingRow("kmw", "Km pe săptămână (pt. costuri fixe)", 1200.0))
        content.addView(costs)

        // praguri
        val th = card()
        th.addView(tv("PRAGURI VERDE / GALBEN / ROȘU", 12f, Ui.MUTED, true))
        th.addView(settingRow("green", "Verde de la (lei/km net)", 2.6))
        th.addView(settingRow("red", "Roșu sub (lei/km net)", 2.0))
        th.addView(settingRow("short", "Cursă scurtă = mereu bună, până la (km total)", 3.0))
        content.addView(th)

        // diagnostic
        val diag = card()
        diag.addView(tv("DIAGNOSTIC", 12f, Ui.MUTED, true))
        val d = Store.dump(this)
        val dv = tv(
            if (d.isEmpty()) "Încă nu am citit nimic din Bolt. Deschide o ofertă cu serviciul activ."
            else "Ultimul text citat din Bolt:\n\n" + d,
            12f, Ui.MUTED
        )
        dv.setTextIsSelectable(true)
        dv.setPadding(0, dp(6), 0, 0)
        diag.addView(dv)
        content.addView(diag)
    }

    private fun numberField(initial: String, onChange: (String) -> Unit): EditText {
        val et = EditText(this)
        et.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
        et.setText(initial)
        et.setTextColor(Ui.TEXT)
        et.textSize = 16f
        et.gravity = Gravity.END
        et.minWidth = dp(90)
        et.setSingleLine(true)
        et.background = Ui.rounded(Ui.SURFACE2, dp(12).toFloat())
        et.setPadding(dp(12), dp(8), dp(12), dp(8))
        et.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                onChange(s?.toString() ?: "")
            }
        })
        return et
    }

    private fun numberRow(label: String, initial: String, onChange: (String) -> Unit): LinearLayout {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(0, dp(5), 0, dp(5))
        val l = tv(label, 14f, Ui.TEXT)
        row.addView(l, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(numberField(initial, onChange))
        return row
    }

    private fun settingRow(key: String, label: String, def: Double): LinearLayout {
        val saved = Store.raw(this, key)
        val initial = saved ?: (if (def == Math.floor(def)) def.toLong().toString() else def.toString())
        return numberRow(label, initial) { v ->
            Store.setRaw(this, key, v)
            simRefresh?.invoke()
        }
    }
}
